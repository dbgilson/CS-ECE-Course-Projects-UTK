#include <fstream>
#include <sstream>
#include <cstdlib>
#include <cstdio>
#include <algorithm>
#include "bitmatrix.h"

Bitmatrix::Bitmatrix(int rows, int cols){
	if(rows <= 0 || cols <= 0){
		fprintf(stderr, "Rows or cols is less than or equal to 0");
		M.resize(1);
		M[0].resize(1, '0');
	}
	else{
		M.resize(rows);
		for(int i = 0; i < M.size(); i++){
			M[i].resize(cols, '0');
		}
	}
}

int Bitmatrix::Rows(){
	return M.size();
}

int Bitmatrix::Cols(){
	return M[0].size();
}

void Bitmatrix::Set(int row, int col, char val){
	char acv;

	if(row < 0 || row >= M.size() || col < 0 || col >= M[0].size()){
        fprintf(stderr, "Bad inputs");
        exit(1);
    }
	
	acv = val;

	if(val == 0){
		acv = '0';
	}

	if(val == 1){
		acv = '1';
	}

	M.at(row).at(col) = acv;
}

char Bitmatrix::Val(int row, int col){
	if(row >= M.size() || row < 0 || col >= M[0].size() || col < 0){
		return -1;
	}

	else if(M[row][col] == '0'){
		return 0;
	}

	else if(M[row][col] == '1'){
		return 1;
	}
}

void Bitmatrix::Print(int w){
  int i, j;

  for (i = 0; i < M.size(); i++) {
    if (w > 0 && i != 0 && i%w == 0) printf("\n");
    if (w <= 0) {
      cout << M[i] << endl;
    } else {
      for (j = 0; j < M[i].size(); j++) {
        if (j % w == 0 && j != 0) printf(" ");
			printf("%c", M[i][j]);
      }
      cout << endl;
    }
  }
}

void Bitmatrix::Write(string fn){
	ofstream f;
	int i, j;

	f.open(fn.c_str());
	if(f.fail()){
		fprintf(stderr, "Failed to open file");
		exit(1);
	}

	for(i = 0; i < M.size(); i++){
		for(j = 0; j < M[i].size(); j++){
			f << M[i][j];
		}
		f << endl;
	}
	f.close();
}

void Bitmatrix::Swap_Rows(int r1, int r2){
	swap(M[r1], M[r2]);
}

void Bitmatrix::R1_Plus_Equals_R2(int r1, int r2){
	char temp;
	unsigned int t1, t2, tempi;

	if(r1 < 0 || r1 >= M.size() || r2 < 0 || r2 >= M.size()){
        fprintf(stderr, "Bad row inputs");
        exit(1);
    }
	
	else{
		for(int i = 0; i < M[0].size(); i++){
			t1 = M[r1][i] - '0';
			t2 = M[r2][i] - '0';
			tempi = (t1 + t2)%2;
			temp = tempi + '0';
			M[r1][i] = temp;
		}
	}
}

Bitmatrix::Bitmatrix(string fn){
  ifstream f;
  int i, j;
  string s, row;

  f.open(fn.c_str());
  if (f.fail()) { perror(fn.c_str()); M.resize(1); M[0].resize(1), M[0][0] = '0'; return; }

  while (getline(f, s)) {
    row.clear();
    for (i = 0; i < s.size(); i++) {
      if (s[i] == '0' || s[i] == '1') {
        row.push_back(s[i]);
      } else if (s[i] != ' ') {
        fprintf(stderr, "Bad matrix file %s\n", fn.c_str());
        M.resize(1); M[0].resize(1), M[0][0] = '0';
        f.close();
        return;
      }
    }
    if (s.size() > 0 && M.size() > 0 && row.size() != M[0].size()) {
	  fprintf(stderr, "Bad matrix file %s\n", fn.c_str());
      M.resize(1); M[0].resize(1), M[0][0] = '0';
      f.close();
      return;
    }
    if (s.size() > 0) M.push_back(row);
  }
  f.close();
}

void Bitmatrix::PGM(string fn, int pixels, int border){
	ofstream f;
	int sRow = 0;
	int sCol = 0;
	int bcountr = 0;
	int bcountc = 0;

	vector<vector<int> > pgm;

	f.open(fn.c_str());

	if(f.fail()){
		fprintf(stderr, "Could not open file");
		exit(1);
	}

	pgm.resize((M.size()*pixels)+(M.size()+1)*border);
	for(int i = 0; i < pgm.size(); i++){
		pgm[i].resize((M[0].size()*pixels)+(M[0].size()+1)*border, 0);
	}

	sRow = border;
	sCol = border;

	for(int j = 0; j < M.size(); j++){
		for(int k = 0; k < M[j].size(); k++){
			if(M[j][k] == '0'){
				for(int l = 0; l < pixels; l++){
					for(int m = 0; m < pixels; m++){
						pgm[(border + l)+(bcountr*(pixels+border))][(border + m)+(bcountc*(pixels+border))] = 255;
					}
				}
			}

			if(M[j][k] == '1'){
				for(int n = 0; n < pixels; n++){
					for(int o = 0; o < pixels; o++){
						pgm[(border + n)+(bcountr*(pixels+border))][(border + o)+(bcountc*(pixels+border))] = 100;
					}
				}
			}
			bcountc++;
		}
		bcountr++;
		bcountc = 0;
	}

	f << "P2" << endl;
	f << pgm[0].size() << " " << pgm.size() << endl;
	f << "255" << endl;

	for(int p = 0; p < pgm.size(); p++){
		for(int q = 0; q < pgm[0].size(); q++){
			if(q == pgm[0].size() - 1){
			    f << pgm[p][q] << endl;
			}
			else{
				f << pgm[p][q] << " ";
			}
		}
	}

	f.close();
}

Bitmatrix *Bitmatrix::Copy(){

	Bitmatrix *N;
	N = new Bitmatrix(M.size(), M[0].size());

	for(int i = 0; i < M.size(); i++){
		for(int j = 0; j < M[i].size(); j++){
			N->M[i][j] = M[i][j];
		}
	}

	return N;
}


BM_Hash::BM_Hash(int size){
	table.resize(size);
}

void BM_Hash::Store(string &key, Bitmatrix *bm){
	int i;
	unsigned int hash, index;
	int test = 0;
	int count = 0;

	hash = 5381;

	for(i = 0; i < key.size(); i++){
		hash = (hash << 5) + hash + key[i];
	}
	
	index = hash % table.size();
	
	if(table[index].size() == 0){

        HTE *temp;
        temp = new HTE;

        temp->key = key;
        temp->bm = bm;

        table[index].push_back(temp);
        return;
	}
	else{
	for(int j = 0; j < table[index].size(); j++){
		if(table[index][j]->key == key){
			table[index][j]->bm = bm;
			return;
		}
		if(count == table[index].size() - 1){
			HTE *temp;
			temp = new HTE;

			temp->key = key;
			temp->bm = bm;

			table[index].push_back(temp);
			return;
		}
		count++;
	}
	}

}

Bitmatrix *BM_Hash::Recall(string &key){
	int i;
    unsigned int hash, index;
    int test = 0;
    int count = 0;

    hash = 5381;

    for(i = 0; i < key.size(); i++){
        hash = (hash << 5) + hash + key[i];
    }

    index = hash % table.size();

	if(table[index].size() == 0){
		return NULL;
	}
	
	else{
    for(int j = 0; j < table[index].size(); j++){
        if(table[index][j]->key == key){
            return table[index][j]->bm;
        }
        if(count == table[index].size() - 1){
            return NULL;
        }
        count++;
    }
	}
}

HTVec BM_Hash::All(){
  HTVec rv;

  for(int i = 0; i < table.size(); i++){
	  for(int j = 0; j < table[i].size(); j++){
		  rv.push_back(table[i][j]);
	  }
  }

  return rv;
}

Bitmatrix *Sum(Bitmatrix *m1, Bitmatrix *m2){
  return NULL;
}

Bitmatrix *Product(Bitmatrix *m1, Bitmatrix *m2){
  return NULL;
}

Bitmatrix *Sub_Matrix(Bitmatrix *m, vector <int> &rows){
  return NULL;
}

Bitmatrix *Inverse(Bitmatrix *m){
  return NULL;
}

