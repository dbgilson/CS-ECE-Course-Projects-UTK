//CS140 Lab 0.5
//The purpose of this code is to read a text map and determine how much "gold" is in the map based on corresponding letters found in the map.

//Include libraries and using namespace as always.
#include <iostream>
using namespace std;

//Overall pretty simple code.  It reads in each input as a char, and if the char is not a '.' or '-', then it sees that it is a letter.
//Since the letter 'A' is int 65 on the ASCII table, then just subtract 64 from the letter to get the right number.
int main(){
	int sum = 0;
	int presum = 0;
	char s;
	char letter;

	while(cin >> s){

		if(s != '.' && s != '-'){
			
			//I made presum so that I could just subtract 64 from the number that the letter gives, then just add it to the actual sum.
			letter = s;
			presum = letter - 64;
			sum = sum + presum;
		}
	}	
	cout << sum << endl;
	return 0;
}

