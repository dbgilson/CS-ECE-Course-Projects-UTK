//CS302, Lab 6
//By: David Gilson
//This code is meant to take maze data created by Mazemake and create a DFS path between the start and finish of the maze.  It first reads in graph data from a file,
//fills out a graph array with walls given by the data, finds a path through it using DFS, and prints out the path to another file.  Like Mazemake, this code is
//only supposed to use c style structures, so I made (more like attempted to make) a stack structure that uses arrays for the purpose of DFS.
#include <unistd.h>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <limits.h>

//Here is the struct for cells
struct cell {
	int i,j;
};

//This is the stack structure I tried to implement.  I tried to do it specifically for cells, but I could not
//get it to completely work, so I commented out the parts that weren't working to get it to compile.
struct Stack{
	cell top;
	unsigned capacity;
	cell* array;
};

struct Stack* createStack(unsigned capacity) { 
    struct Stack* stack = (struct Stack*)malloc(sizeof(struct Stack)); 
    stack->capacity = capacity; 
    stack->top.i = -1;
	stack->top.j = -1;
    stack->array = (cell*)malloc(stack->capacity * sizeof(int)); 
    return stack; 
} 

// Stack is full when top is equal to the last index 
int isFull(struct Stack* stack) { 
    return (stack->top.i + stack->top.j) == stack->capacity - 1; 
} 
  
// Stack is empty when top is equal to -2
int isEmpty(struct Stack* stack) { 
    return (stack->top.i + stack->top.j) == -2; 
} 
  
// Function to add an item to stack.  It increases top by 1 
void push(struct Stack* stack, cell item) { 
    if (isFull(stack)) 
        return; 
   // stack->array[++stack->top] = item;  
} 
  
// Function to remove an item from stack.  It decreases top by 1 
cell pop(struct Stack* stack) { 
	cell temp;
	temp.j = -1;
	temp.j = -1;
    if (isEmpty(stack)) 
        return temp; 
    //return stack->array[stack->top--]; 
} 

// Function to return the top from stack without removing it 
cell peek(struct Stack* stack) {
	cell temp;
	temp.i = -1;
	temp.j = -1;
    if (isEmpty(stack)) 
        return temp; 
    //return stack->array[stack->top]; 
}
 
//Here is the dfs solver function to find the path of the maze.  I had little luck trying to implement it, though, so I left a main part of it
//commented out using/* */.  I referenced the augmented_dfs function in the graph6 handout when trying to make this function iteratively.
void dfs(cell &source, cell &sink, bool &iswhite, cell &link, bool &wall){	
	//initialize stack (iswhite and link are already initialized)
	struct Stack *s = createStack((sink.i + 1) * (sink.j + 1));
	push(s, source);

	int Nrow = sink.i + 1;
	int Ncol = sink.j + 1;

	while(!isEmpty(s)){
		cell i = peek(s);
		cell temp;

		temp = pop(s);

		//iswhite[i.i][i.j] = false;
		if(i.i == sink.i && i.j == sink.j){
			break;
		}

		for(int j = (sink.i + 1) * (sink.j + 1) - 1; j >= 0; j--){
			cell jcell;

			//use Nrow and Ncol to find jcell.i and jcell.j
			//(Couldn't figure it out, so just used 1 to compile)
			jcell.i = 1;
			jcell.j = 1;

			/*
			if(iswhite[jcell.i][jcell.j] == false){
				continue;
			}
			
			//No wall to North of cell
			if(wall[jcell.i][jcell.j][0] == false){
				link[jcell.i][jcell.j] = i;
				push(s, i);
			}
			//No wall to East of cell
			if(wall[jcell.i][jcell.j][1] == false){
				link[jcell.i][jcell.j] = i;
				push(s, i);
			}
			//No wall to South of cell
			if(wall[jcell.i][jcell.j][2] == false){
				link[jcell.i][jcell.j] = i;
				push(s, i);
			}
			//No wall to West of cell
			if(wall[jcell.i][jcell.j][3] == false){
				link[jcell.i][jcell.j] = i;
				push(s, i);
			}
			*/
		}
	}
	while(!isEmpty(s)){
		cell temp;
		temp = pop(s);
	}

}
	
int main(int argc, char *argv[]) {
  if (argc != 3) {
    //print usage error message to stderr
	fprintf(stderr, "Error: Command Line Arguments Invalid\n");
	return 0;
  } 

  //open input file for reading
  //open output file for writing
  FILE *fin, *fout;
  fin = fopen(argv[1], "r");
  fout = fopen(argv[2], "w");

  int Nrow;
  int Ncol;

  //determine Nrow,Ncol from input file
  fscanf(fin, "MAZE %d %d\n", &Nrow, &Ncol);

  //create array of walls for each grid cell
  //initialize to have boundary walls set and
  //interior walls unset

  bool wall[Nrow][Ncol][4];
  
  //read input file, set interior walls
  int i1, j1, i2, j2;
  //bool: 4 -> N, E, S, W
  while(fscanf(fin, "%3d %3d %3d %3d\n", &i1, &j1, &i2, &j2) != EOF){
	  if(i1 == i2 && j2 > j1){
		  wall[i1][j1][1] = true;
		  wall[i2][j2][3] = true;
	  }
	  else if(j1 == j2 && i2 > i1){
		  wall[i1][j1][2] = true;
		  wall[i2][j2][0] = true;
	  }
  }

  //initalize DFS path computation
  //source = (0,0)
  //sink = (Nrow-1,Ncol-1)
  cell source, sink;
  source.i = 0;
  source.j = 0;
  sink.i = Nrow-1;
  sink.j = Ncol-1;

  bool iswhite[Nrow][Ncol];
  cell link[Nrow][Ncol];

  //initialize iswhite and link arrays
  for(int i = 0; i < Nrow - 1; i++){
	  for(int j = 0; j < Ncol - 1; j++){
		  link[i][j].i = -1;
		  link[i][j].j = -1;
		  iswhite[i][j] = true;
	  }
  }

  //carry out DFS source-to-sink computation
  ///////////////////////////////////////////////////////////
  //This function call is commented out because I had errors compiling it with iswhite, link, and wall

  /*
  dfs(source, sink, iswhite, link, wall);
  */

  //write PATH, Nrow, Ncol header
  fprintf(fout, "PATH %d %d\n", Nrow, Ncol);

  //write cells on path to file

  cell temp = source;
  while(true){
	  fprintf(fout, "%3d %3d\n", temp.i, temp.j);

	  if(temp.i == sink.i && temp.j == sink.j){
		  break;
	  }

	  temp = link[temp.i][temp.j];
  }

  //close open files
  fclose(fin);
  fclose(fout);
  
  return 0;
}
