//CS302, Lab 6
//By: David Gilson
//The purpose of this code was to create a maze given a column and row size.  It would first make a maze "graph" by using arrays,
//then it would fill that graph with interior walls.  We then randomly perturbed the graphand then randomly took down walls until we had a 
//path between the upper left of the graph to the lower right.  We found that there was a path using disjointed sets, and we wrote the graph
//walls to a file so that they could be read.  This lab is also supposed to be c style, not c++.
#include <cstdlib>
#include <ctime>
#include <cstdio>
#include "dset.h"

//Struct to create cell structure
struct cell {
	int i, j;
};

//Swap functions to swap 2 cells.
void swap(cell &c1, cell &c2) {
	int m, n;
	m = c1.i;
	n = c1.j;

	c1.i = c2.i;
	c1.j = c2.j;
	c2.i = m;
	c2.j = n;
}

int main(int argc, char *argv[]) {
  if (argc != 4) {
	//print usage error message to stderr
	fprintf(stderr, "Error: Command line arguments are not valid\n");
    return 0;
  }

  int Nrow = atoi(argv[1]);
  int Ncol = atoi(argv[2]);

  //int N = number of interior grid walls
  int N = ((Ncol - 1) * Nrow) + ((Nrow - 1) * Ncol);;
  cell wall[N][2];
	
  //populate wall[][] with interior grid walls
  int k = 0;
  for(int i = 0; i < Ncol - 1; i++){
	  for(int j = 0; j < Nrow; j++){
		  cell temp;
		  temp.i = i;
		  temp.j = j;
		  
		  wall[k][0] = temp;
		  
		  temp.i = i + 1;
		  
		  wall[k][1] = temp;
		  
		  k++;
	  }
  }

  k = 0;
  for(int i = 0; i < Ncol; i++){
	  for(int j = 0; j < Nrow - 1; j++){
		  cell temp;
		  temp.i = i;
		  temp.j = j;

		  wall[k][0] = temp;

		  temp.j = j + 1;

		  wall[k][1] = temp;

		  k++;
	  }
  }  

  //randomly perturb list order: swap based
	for(int i = N - 1; i > 0; --i){
		int j = rand() % (i + 1);
		swap(wall[i][0], wall[j][0]);
		swap(wall[i][1], wall[j][1]);
	}
  
  //open output file for writing (argv[3])
  FILE *fp;
  fp = fopen(argv[3], "w");
  fprintf(fp, "MAZE %d %d\n", Nrow, Ncol);
 
  dset *ds;
  dset_setup(ds, Nrow * Ncol);

  for (k=0; k<N; k++) {
    //if: pair of cells given by wall[k][] are not
	//connected (belong to different disjoint sets),
	//merge them

	int i = (wall[k][0].i * (Ncol - 1) ) + (wall[k][0].j);
	int j = (wall[k][1].i * (Ncol - 1) ) + (wall[k][1].j);

	if(dset_find(ds, i) != dset_find(ds,j)){
		dset_merge(ds, i, j);
	}
	//else: write wall to file in the form of the
	//two pairs of cell indices (i0,j0) (i1,j1)
	
	//printf("got past dset find and merge\n");

	else{
		fprintf(fp, "%3d %3d %3d %3d\n", 
				wall[k][0].i, wall[k][0].j,
				wall[k][1].i, wall[k][1].j);
	}
	
    //if: all cells belong to the same set, break
	if(dset_size(ds) == 1){
		break;
	}
  }

 //write any remaining walls to file
 k++;
 while(k < N){
	fprintf(fp, "%3d %3d %3d %3d\n",
             wall[k][0].i, wall[k][0].j,
             wall[k][1].i, wall[k][1].j);
 }	 

  //close output file
  fclose(fp);

  //Deallocate ds
  dset_free(ds);

  return 0;
}
